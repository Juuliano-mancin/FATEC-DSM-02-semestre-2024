<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exemplo1</title>
</head>
<body>
    <?php
        $n1 = 3;
        $n2 = 5;

        $soma = $n1 + $n2;

        echo "<p> num1: $n1 / num2: $n2";
        echo "<p> A soma dos números é $soma";
    ?>
</body>
</html>