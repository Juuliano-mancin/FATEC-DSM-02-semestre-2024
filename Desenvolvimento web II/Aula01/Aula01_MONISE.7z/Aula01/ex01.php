<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercício 1</title>
</head>
<body>
    <?php
        $base = 10;
        $altura = 5;
        $area = ($base * $altura)/2;

        echo "<p>A base do triângulo: $base";
        echo "<p>A altura do triângulo: $altura";
        echo "<p>A área do triângulo: $area";
    ?>
</body>
</html>