<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercício 2</title>
</head>
<body>
    <?php
        $nota1 = 8;
        $nota2 = 10;
        $nota3 = 6;

        $media = ($nota1 + $nota2 + $nota3)/3;

        echo "<p> A primeira nota: $nota1 </p>";
        echo "<p> A primeira nota: $nota2 </p>";
        echo "<p> A primeira nota: $nota3 </p>";

        echo "<p> A media: $media </p>";
    ?>
</body>
</html>