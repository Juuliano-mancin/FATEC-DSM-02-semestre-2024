package model;

public class Moto extends Veiculo {
    private int cilindradas;

    // Construtor
    public Moto() {
        super(); // Chama o construtor da classe Veiculo
    }

    // Getter para cilindradas
    public int getCilindradas() {
        return cilindradas;
    }

    // Setter para cilindradas
    public void setCilindradas(int cilindradas) {
        this.cilindradas = cilindradas;
    }
}
