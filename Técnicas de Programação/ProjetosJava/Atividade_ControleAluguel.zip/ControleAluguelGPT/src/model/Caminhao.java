package model;

public class Caminhao extends Veiculo {
    private double capacidadeCarga;

    // Construtor
    public Caminhao() {
        super(); // Chama o construtor da classe Veiculo
    }

    // Getter para capacidadeCarga
    public double getCapacidadeCarga() {
        return capacidadeCarga;
    }

    // Setter para capacidadeCarga
    public void setCapacidadeCarga(double capacidadeCarga) {
        this.capacidadeCarga = capacidadeCarga;
    }
}
