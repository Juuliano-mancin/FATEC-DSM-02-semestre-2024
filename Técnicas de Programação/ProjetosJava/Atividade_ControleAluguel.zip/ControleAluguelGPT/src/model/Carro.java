package model;

public class Carro extends Veiculo {
    private int numeroPortas;

    // Construtor
    public Carro() {
        super(); // Chama o construtor da classe Veiculo
    }

    // Getter para numeroPortas
    public int getNumeroPortas() {
        return numeroPortas;
    }

    // Setter para numeroPortas
    public void setNumeroPortas(int numeroPortas) {
        this.numeroPortas = numeroPortas;
    }
}
