import model.Aluguel;
import model.Caminhao;
import model.Carro;
import model.Moto;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class GerenciarControleAluguel {
    public static void main(String[] args) {
        // Criar instâncias de Carro, Moto e Caminhão
        Carro carro = new Carro();
        Moto moto = new Moto();
        Caminhao caminhao = new Caminhao();

        // Preencher dados do Carro
        carro.setPlaca("ABC1234");
        carro.setMarca("Fiat");
        carro.setModelo("Uno");
        carro.setAno(2020);

        // Criar o objeto aluguel para o carro
        Aluguel aluguelCarro = new Aluguel();
        aluguelCarro.setVeiculo(carro);
        aluguelCarro.setDataAluguel(LocalDate.now()); // Registra a data atual
        LocalDateTime horaRetiradaCarro = LocalDateTime.now(); // Registra o horário atual
        aluguelCarro.setHoraAluguel(horaRetiradaCarro); // Define a hora de retirada
        aluguelCarro.setHoraDevolucao(horaRetiradaCarro.plusHours(2)); // Define a hora de devolução como 2 horas depois

        // Apresentar o registro de aluguel do carro
        System.out.println("Dados do Aluguel do Carro:");
        aluguelCarro.apresentarRegistroAluguel();

        // Registrar a devolução do carro
        try {
            Thread.sleep(1000); // Aguarda 1 segundo
        } catch (InterruptedException e) {
            e.printStackTrace(); // Trata a exceção
        }

        LocalDateTime horaDevolucaoCarro = LocalDateTime.now(); // Hora atual para devolução
        aluguelCarro.setHoraDevolucao(horaDevolucaoCarro); // Atualiza a hora de devolução
        System.out.println("\nDados da Devolução do Carro:");
        aluguelCarro.apresentarRegistroAluguel();

        // Preencher dados da Moto
        moto.setPlaca("XYZ9876");
        moto.setMarca("Honda");
        moto.setModelo("CG");
        moto.setAno(2021);

        // Criar o objeto aluguel para a moto
        Aluguel aluguelMoto = new Aluguel();
        aluguelMoto.setVeiculo(moto);
        aluguelMoto.setDataAluguel(LocalDate.now()); // Registra a data atual
        LocalDateTime horaRetiradaMoto = LocalDateTime.now(); // Registra o horário atual
        aluguelMoto.setHoraAluguel(horaRetiradaMoto); // Define a hora de retirada
        aluguelMoto.setHoraDevolucao(horaRetiradaMoto.plusHours(2)); // Define a hora de devolução como 2 horas depois

        // Apresentar o registro de aluguel da moto
        System.out.println("\nDados do Aluguel da Moto:");
        aluguelMoto.apresentarRegistroAluguel();

        // Registrar a devolução da moto
        try {
            Thread.sleep(1000); // Aguarda 1 segundo
        } catch (InterruptedException e) {
            e.printStackTrace(); // Trata a exceção
        }

        LocalDateTime horaDevolucaoMoto = LocalDateTime.now(); // Hora atual para devolução
        aluguelMoto.setHoraDevolucao(horaDevolucaoMoto); // Atualiza a hora de devolução
        System.out.println("\nDados da Devolução da Moto:");
        aluguelMoto.apresentarRegistroAluguel();

        // Preencher dados do Caminhão
        caminhao.setPlaca("DEF5678");
        caminhao.setMarca("Volvo");
        caminhao.setModelo("FH");
        caminhao.setAno(2019);

        // Criar o objeto aluguel para o caminhão
        Aluguel aluguelCaminhao = new Aluguel();
        aluguelCaminhao.setVeiculo(caminhao);
        aluguelCaminhao.setDataAluguel(LocalDate.now()); // Registra a data atual
        LocalDateTime horaRetiradaCaminhao = LocalDateTime.now(); // Registra o horário atual
        aluguelCaminhao.setHoraAluguel(horaRetiradaCaminhao); // Define a hora de retirada
        aluguelCaminhao.setHoraDevolucao(horaRetiradaCaminhao.plusHours(2)); // Define a hora de devolução como 2 horas depois

        // Apresentar o registro de aluguel do caminhão
        System.out.println("\nDados do Aluguel do Caminhão:");
        aluguelCaminhao.apresentarRegistroAluguel();

        // Registrar a devolução do caminhão
        try {
            Thread.sleep(1000); // Aguarda 1 segundo
        } catch (InterruptedException e) {
            e.printStackTrace(); // Trata a exceção
        }

        LocalDateTime horaDevolucaoCaminhao = LocalDateTime.now(); // Hora atual para devolução
        aluguelCaminhao.setHoraDevolucao(horaDevolucaoCaminhao); // Atualiza a hora de devolução
        System.out.println("\nDados da Devolução do Caminhão:");
        aluguelCaminhao.apresentarRegistroAluguel();

        System.out.println("\nTodos os registros de aluguel foram processados com sucesso.");
    }
}
